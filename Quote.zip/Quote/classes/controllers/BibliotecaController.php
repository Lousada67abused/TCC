<?php 
class BibliotecaController {
}
?>