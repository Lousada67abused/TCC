<?php 
class MetaLeituraController {
}
?>