<?php 
class SeguidorController {
}
?>